"""
URL configuration for cakeshop project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from cakeapp import views

from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.index),
    path('about',views.about),
    path('contact',views.contact),
    path('service',views.service),
    path('team',views.team),
    path('testimonial',views.testimonial),
    path('menu',views.menu),
    path('registration',views.registration),
    path('login',views.login),
    path('dblogin',views.dblogin),
    path('adminlogin',views.adminlogin),
    path('adminhome',views.adminhome,name='adminhome'),
    path('userhome',views.userhome,name='userhome'),
    path('dbhome',views.dbhome),
    path('viewuser',views.viewuser,name='viewuser'),
    path('addproduct',views.addproduct,name='addproduct'),
    path('manageproduct',views.manageproduct,name='manageproduct'),
    path('orderdetails',views.orderdetails),
    path('update/<int:d>', views.update_product),
    path('delete/<int:d>',views.delete_product),
    path('mform',views.mform),
    path('cake',views.cake,name='cake'),
    # path('viewchefs',views.viewchefs),
    path('dbboy',views.dbboy),
    path('cart', views.cart1,name='cart'),
    path('wishlist',views.wishlist,name='wishlist'),
    path('add_wishlist/<int:d>',views.add_wishlist),
    path('delete_wishlist/<int:d>',views.deletewishlist),
    path('add_cart/<int:d>', views.add_cart),
    path('delete_cart/<int:d>', views.deletecart),
    path('increment/<int:d>', views.increment),
    path('decrement/<int:d>', views.decrement),
    path('logout',views.logout),
    # path('update_profile/<int:d>', views.update_profile),
    path('profile', views.profile,name='profile'),
    path('update/', views.update_profile),
    path('checkout/<int:d>',views.checkout),
    path('checkout_cart/<int:total>/<int:qty>', views.checkoutcart),
    path('payment/<int:l>/<int:d>/<int:k>', views.payment),
    path('payment_cart/<int:l>', views.paymentcart),
    path('payment_success', views.paymentsuccess),
    path('payment_success_cart', views.paymentsuccess_cart),
    path('user_recent_orders',views.userrecentorders,name='user_recent_orders'),
    path('admin_recent_orders',views.adminrecentorders),
    path('admin_order_update/<int:d>',views.adminorderupdate),
    path('reset/<token>', views.reset_password),
    path('forgot', views.forgot_password),
    path('lowstock', views.lowstock),


]

if settings.DEBUG:
    urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
