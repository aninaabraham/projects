from django.db import models

# Create your models here.
class register(models.Model):
    name=models.CharField(max_length=30)
    email=models.EmailField()
    phno=models.IntegerField()
    address=models.CharField(max_length=30)
    username=models.CharField(max_length=20)
    password=models.CharField(max_length=20)
    city = models.CharField(max_length=15, null=True)
    state = models.CharField(max_length=20, null=True)
    country = models.CharField(max_length=15, null=True)
    pincode = models.CharField(max_length=10, null=True)

    def __str__(self):
        return self.username
class products(models.Model):
    productname = models.CharField(max_length=300)
    price = models.IntegerField()
    stock = models.IntegerField(default=1,null=True)
    image = models.FileField()

class deliveryboy(models.Model):
    name=models.CharField(max_length=30)
    email=models.EmailField()
    phno=models.IntegerField()
    username=models.CharField(max_length=20)
    password=models.CharField(max_length=20)
    proof=models.FileField()
    status=models.CharField(max_length=10,default='pending',null=True)

class cart_1(models.Model):
    user_details=models.ForeignKey(register,on_delete=models.CASCADE)
    product_details=models.ForeignKey(products,on_delete=models.CASCADE)
    quantity=models.IntegerField(default=1,null=True)
    total_price = models.IntegerField(default=0)

class wishlist_1(models.Model):
    user_details = models.ForeignKey(register, on_delete=models.CASCADE)
    product_details = models.ForeignKey(products, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1, null=True)



class Order(models.Model):
    user = models.ForeignKey(register, on_delete=models.CASCADE)
    name = models.CharField(max_length=30)
    address = models.CharField(max_length=50)
    city = models.CharField(max_length=15)
    state = models.CharField(max_length=15)
    country = models.CharField(max_length=15)
    zip_code = models.CharField(max_length=10, null=True)
    phone = models.CharField(max_length=15)
    delivery_date = models.DateField()
    product_order = models.ForeignKey(products, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)
    total_price = models.IntegerField()
    payment_status = models.CharField(max_length=20,null=True)
    purchase_date = models.DateTimeField(auto_now=True, null=True)
    product_status = models.CharField(max_length=50,null=True, default='Order Placed')
    instruction = models.CharField(max_length=50,null=True, default='Your Order Has Been Successfully Placed')



    def __str__(self) -> str:
        return f'{self.name}'

class Mail(models.Model):
    mail = models.CharField(max_length=25)
    def __str__(self):
        return self.mail

class PasswordReset(models.Model):
    user=models.ForeignKey(register,on_delete=models.CASCADE)
    token=models.CharField(max_length=10)

