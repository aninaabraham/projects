from django.contrib import admin

# Register your models here.
from .models import *
admin.site.register(register)
admin.site.register(products)
admin.site.register(deliveryboy)
admin.site.register(cart_1)
admin.site.register(wishlist_1)
admin.site.register(Order)
admin.site.register(Mail)