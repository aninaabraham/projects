from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib import messages
import razorpay


# Create your views here.
def index(re):
    return render(re,'index.html')

def about(re):
    return render(re,'about.html')

def contact(re):
    return render(re,'contact.html')

def menu(re):
    return render(re,'menu.html')

def service(re):
    return render(re,'service.html')

def team(re):
    return render(re,'team.html')

def testimonial(re):
    return render(re,'testimonial.html')

from.models import*
def registration(re):

    if re.method == "POST":
        a =re.POST['name']
        b = re.POST['email']
        c =int(re.POST['phno'])
        d =re.POST['address']
        e =re.POST['username']
        f =re.POST['password']
        g =re.POST['confirmpassword']
        if f==g:
          data= register.objects.create(name=a,email=b,phno=c,address=d,username=e,password=f)
          data.save()
          return HttpResponse("<script>alert('registration successfull')</script>")
        else:
            return HttpResponse('doesnot exist ')

    return render(re, "registration.html")

def dbboy(re):

    if re.method == "POST":
        a =re.POST['name']
        b = int(re.POST['phno'])
        c = re.POST['email']
        d =re.POST['username']
        e =re.POST['password']
        f =re.POST['confirmpassword']
        g=re.POST['proof']
        if e==f:
          data= deliveryboy.objects.create(name=a,phno=b,email=c,username=d,password=f,proof=g)
          data.save()
          return HttpResponse("<script>alert('registration successfull')</script>")
        else:
            return HttpResponse('doesnot exist ')

    return render(re, "deliveryboy.html")

def login(re):
    if re.method == "POST":
        d = re.POST['username']  # to get data
        e = re.POST['password']
        try:
            data = register.objects.get(username=d)  # to get the username
            print(data)
            if e == data.password:
                re.session['user'] = d
                print(re.session['user'])
                print(data.password)  # password field
                # return HttpResponse("<script>alert('login successfully')</script>")
                return redirect(userhome)
            return HttpResponse("Password Incorrect")  # work as else

        except Exception:
            # if d == 'admin' and e == '1234':
            #     re.session['admin'] = d
            #     return redirect(adminhome)
            # else:
              return HttpResponse("invalid usrname and password for user")
    else:
        return render(re, 'login.html')


def dblogin(re):
     if re.method == "POST":
         d = re.POST['username']  # to get data
         e = re.POST['password']
         try:
             data = deliveryboy.objects.get(username=d)  # to get the username
             print(data)
             if e == data.password:
                 re.session['db'] = d
                 print(re.session['db'])
                 print(data.password)  # password field
                 # return HttpResponse("<script>alert('login successfully')</script>")
                 return redirect(dbhome)
             return HttpResponse("Password Incorrect")  # work as else

         except Exception:
             # if d == 'admin' and e == '1234':
             #     re.session['admin'] = d
             #     return redirect(adminhome)
             # else:
             return HttpResponse("invalid usrname and password for db")
     else:
         return render(re, 'dblogin.html')


def adminlogin(re):
    if re.method == "POST":
        d = re.POST['username']  # to get data
        e = re.POST['password']
        try:
            # data = register.objects.get(username=d)  # to get the username
            # print(data)
            if d == 'admin' and e == '1234':
                re.session['admin'] = d
                print(re.session['admin'])
                # print(data.password)  # password field
                # return HttpResponse("<script>alert('login successfully')</script>")
                return redirect(adminhome)
            return HttpResponse("Password Incorrect")  # work as else

        except Exception:
            # if d == 'admin' and e == '1234':
            #     re.session['admin'] = d
            #     return redirect(adminhome)
            # else:
            return HttpResponse("invalid usrname and password for admin")
    else:
        return render(re, 'login.html')


def userhome(re):
    if 'user' in re.session:
       return render(re,'userhome.html')
    return redirect(login)

def adminhome(re):
    if 'admin' in re.session:
       return render(re,'adminhome.html')
    return redirect(login)
def dbhome(re):
    if 'db' in re.session:
       return render(re,'dbhome.html')
    return redirect(login)

def viewuser(re):
    if 'admin' in re.session:
        d = register.objects.all()
    return render(re, 'viewuser.html', {'r': d})


def addproduct(re):
    if 'admin' in re.session:
        if re.method=='POST':
            a=re.POST['productname']
            b=re.POST['price']
            c=re.POST['stock']
            d=re.FILES['image']
            products.objects.create(productname=a,price=b,stock=c,image=d).save()
            messages.success(re,'Product added,DATA SAVED')
        return render(re,'addproduct.html')
    return redirect(login)

def manageproduct(re):
    if 'admin' in re.session:
        data =products.objects.all()
        print(data)
        return render(re,'manageproduct.html',{'data':data})
    return redirect(login)

def orderdetails(re):
    return render(re,'orderdetails.html')

from. forms import*
def update_product(re,d):
    if 'admin' in re.session:
        data=products.objects.get(pk=d)
        print(data)
        n=model_form1(instance=data)
        if re.method=='POST':
            n=model_form1(re.POST,re.FILES,instance=data)
            if n.is_valid():
                n.save()
                messages.success(re, 'product updated succesfully')
                return  redirect(manageproduct)

        return render(re,'update_product.html',{'data':n})
        #     a=re.POST['productname']
        #     b=re.POST['price']
        #     c=re.POST['stock']
        #     products.objects.filter(pk=d).update(productname=a,price=b,stock=c)
        #     return redirect(manageproduct)

    return redirect(login)



def mform(re):
    n=model_form()
    if re.method == 'POST':
        n = model_form(re.POST, re.FILES)
        if n.is_valid():
            n.save()
            return HttpResponse('saved')
    return  render(re,'model_form.html',{'data':n})

def delete_product(re,d):
    if 'admin' in re.session:
        data=products.objects.get(pk=d)
        data.delete()
        messages.success(re,'product deleted succesfully')
        return redirect(manageproduct)
    return redirect(login)

def cake(re):
    if 'user' in re.session:
       d = products.objects.all()
       return render(re, 'cake.html', {'d': d})
    return redirect(login)

# def viewchefs(re):
#     if 'admin' in re.session:
#         d = masterchefs.objects.all()
#     return render(re, 'viewchefs.html', {'r': d})
def cart1(re):
    # if 'user'in re.session:
    #       data=register.objects.get(username=re.session['user'])
    #       d=cart_1.objects.filter(user_details=data)
    #       return render(re,'cart.html',{'m':d})
    # return redirect(login)
    if 'user' in re.session:
        # user = register.objects.get(email=re.session['user'])
        data = register.objects.get(username=re.session['user'])
        cart_items = cart_1.objects.filter(user_details=data)
        qty = 0
        total = 0
        for i in cart_items:
            qty += i.quantity
            total += i.product_details.price * i.quantity
        if not cart_items:
            return render(re, 'cart.html')

        return render(re, 'cart.html', {'cart_items': cart_items, 'total': total, 'qty': qty})
    return redirect(login)

def add_cart(re,d):
    if 'user' in re.session:
        u=register.objects.get(username=re.session['user'])
        p=products.objects.get(pk=d)
        if cart_1.objects.filter(product_details=p).exists():
              b = cart_1.objects.get(product_details_id=d)
              b.quantity=b.quantity+1
              print(b.quantity)
              # data = cart_1.objects.create(user_details=a, product_details=b)
              b.save()
              return redirect(cart1)
        else:
            cart_1.objects.create(user_details=u,product_details=p).save()
            messages.success(re, 'Item added to cart succesfully')
        return redirect(cake)
    return redirect(login)






def deletecart(request,d):
  if 'user' in request.session:
    data = cart_1.objects.get(pk=d)
    data.delete()
    messages.success(request,'Succefully Deleted')
    return redirect(cart1)

def increment(re,d):
    if 'user'in re.session:
        data=cart_1.objects.get(pk=d)
        if data.quantity>=1:
         data.quantity+=1
         data.save()
         data.total_price = data.quantity * data.product_details.price
    return redirect(cart1)

def decrement(re,d):
    if 'user'in re.session:
        data=cart_1.objects.get(pk=d)
        if data.quantity >= 1:
          data.quantity-=1
          data.save()
    return redirect(cart1)

def wishlist(re):
    if 'user'in re.session:
          data=register.objects.get(username=re.session['user'])
          d=wishlist_1.objects.filter(user_details=data)
          return render(re,'wishlist.html',{'m':d})
    return redirect(login)

def add_wishlist(re,d):
    # if 'user' in re.session:
    #     u=register.objects.get(username=re.session['user'])
    #     p=products.objects.get(pk=d)
    #     if wishlist_1.objects.filter(product_details=p).exists():
    #         messages.success(re,'Item already exists')
    #     else:
    #         wishlist_1.objects.create(user_details=u,product_details=p).save()
    #         messages.success(re, 'Item added to wishlist succesfully')
    #     return redirect(cake)
    # return redirect(login)
    a = register.objects.get(username=re.session['user'])
    b = products.objects.get(pk=d)
    data = wishlist_1.objects.create(user_details=a, product_details=b)
    data.save()
    return redirect(wishlist)


def deletewishlist(request,d):
  if  'user' in request.session:
    data = wishlist_1.objects.get(pk=d)
    data.delete()
    messages.success(request,'Succefully Deleted')
    return redirect(wishlist)




def logout(re):
    if 'user' in re.session or 'admin' in re.session or  'db' in re.session :
        re.session.flush()
        return redirect(login)

def profile(re):
    if 'user' in re.session:
        data=register.objects.get(username=re.session['user'])
        return render(re, 'profile.html',{'d':data} )

def update_profile(re):
    if 'user' in re.session:
        data=register.objects.get(username=re.session['user'])
        print(data)
        n=model_form(instance=data)
        if re.method=='POST':
            n=model_form(re.POST,re.FILES,instance=data)
            if n.is_valid():
                n.save()
                # messages.success(re, 'product deleted succesfully')
                return  redirect(profile)

        return render(re,'update_profile.html',{'data':n})
        #     a=re.POST['productname']
        #     b=re.POST['price']
        #     c=re.POST['stock']
        #     products.objects.filter(pk=d).update(productname=a,price=b,stock=c)
        #     return redirect(manageproduct)

    return redirect(login)

def checkout(request,d):
    # user = register.objects.get(email=request.session['user'])
    data = register.objects.get(username=request.session['user'])
    pro = products.objects.get(pk=d)

    if request.method=='POST':
        a = request.POST.get('chname')
        c = request.POST.get('chaddress')
        m = request.POST.get('chcity')
        e = request.POST.get('chstate')
        f = request.POST.get('chcountry')
        g = request.POST.get('chzipcode')
        h = request.POST.get('chphone')
        k = int(request.POST.get('chqty'))
        l = int(request.POST.get('chtotal'))
        p = request.POST.get('setTodaysDate')
        if pro.stock >= 1:
            val = Order.objects.create(user=data, name=a, address=c, city=m, state=e, country=f, zip_code=g, phone=h,delivery_date=p, product_order=pro, quantity=k, total_price=l )
            val.save()
            request.session['order_name']= pro.productname
            request.session['order_id'] = val.pk

            return redirect(payment,l,d,k)
        else:
            messages.error(request,'Low Stock')
            return redirect(cake)
    return render(request, 'checkout.html',{'data':pro, 'user':data})

def checkoutcart(request,total,qty):
    # user = register.objects.get(email=request.session['user'])
    data = register.objects.get(username=request.session['user'])
    pro=cart_1.objects.filter(user_details=data)
    order_ids = []
    if request.method == 'POST':
        a = request.POST.get('chname')
        c = request.POST.get('chaddress')
        d = request.POST.get('chcity')
        e = request.POST.get('chstate')
        f = request.POST.get('chcountry')
        g = request.POST.get('chzipcode')
        h = request.POST.get('chphone')
        l = int(request.POST.get('chtotal'))
        k=request.POST.get('setTodaysDate')
        print(k)
        for i in pro:
            cn = i.product_details
            cq = i.quantity
            ct = i.product_details.price * i.quantity
            v=Order(user=data, name=a, address=c, city=d, state=e, country=f, zip_code=g, phone=h,    delivery_date=k, product_order=cn,quantity=cq,total_price=ct)
            v.save()
            value1 = v.pk
            order_ids.append(value1)
            if i.product_details.stock >=1:
                products.objects.filter(pk=i.product_details.pk).update(stock=i.product_details.stock-cq)
                request.session['order_ids'] = order_ids
                return redirect(paymentcart, l)
            else:
                messages.error(request,'Low Stock')
                return redirect(cart1)


    return render(request,'checkout_cart.html',{'user':data,'data':pro,'total':total,'qty':qty})

def payment(request,l,d,k):
    pro = products.objects.get(pk=d)
    amount = l * 100
    order_currency = 'INR'
    client = razorpay.Client(
        auth=("rzp_test_SROSnyInFv81S4", "WIWYANkTTLg7iGbFgEbwj4BM"))
    payment = client.order.create({'amount': amount, 'currency': 'INR', 'payment_capture': '1'})
    if pro.stock >=1:
        products.objects.filter(pk=pro.id).update(stock =pro.stock-k)
    # status='PAID'
    # Order.objects.filter(pk=v).update(payment_status=status)
    return render(request, "payment.html",{'amount':amount})

def paymentsuccess(request):
    user=register.objects.get(username=request.session['user'])
    a = request.session['order_id']
    print(a)
    b = 'PAID'
    c = request.session['order_name']
    print(c)
    Order.objects.filter(pk=a).update(payment_status=b)
    # send_mail('Payment Successful',
    #           f'Hey {user.name}, Your payment was successful and order for {c} has been successfully placed. \nWe are working on your order. \nOrder status will be updated soon.\n\nTHANK YOU.. \n\nBest regards,\nGAMER ZONE',
    #           'settings.EMAIL_HOST_USER', [user.email], fail_silently=False)
    # send_mail('New Order',
    #           f' {user.name}, has placed a new order for {c}\nPlease review and update the order status',
    #           'settings.EMAIL_HOST_USER', ['gmrznadmn@gmail.com'], fail_silently=False)
    return render(request, "payment_sucess.html")

def paymentcart(request,l):
    amount = l * 100
    order_currency = 'INR'
    client = razorpay.Client(
        auth=("rzp_test_SROSnyInFv81S4", "WIWYANkTTLg7iGbFgEbwj4BM"))
    payment = client.order.create({'amount': amount, 'currency': 'INR', 'payment_capture': '1'})
    return render(request, "payment_cart.html",{'amount':amount})

def paymentsuccess_cart(request):
    usr = register.objects.get(username=request.session['user'])
    order_ids = request.session.get('order_ids', [])
    for i in order_ids:
        c = i
        b = 'PAID'
        Order.objects.filter(pk=c).update(payment_status=b)
    # send_mail('Payment Successful',
    #           f'Hey {usr.name}, Your payment was successful and your ordered items has been successfully placed. \nWe are working on your order. \nOrder status will be updated soon.\n\nTHANK YOU.. \n\nBest regards,\nGAMER ZONE',
    #           'settings.EMAIL_HOST_USER', [usr.email], fail_silently=False)
    # send_mail('New Order',
    #           f' {usr.name}, has placed a some new orders\nPlease review and update the order status',
    #           'settings.EMAIL_HOST_USER', ['aninaabraham01@gmail.com'], fail_silently=False)
    return render(request, "payment_sucess.html")

def mail(request):
    m = request.POST['mail']
    data =Mail.objects.create(mail=m)
    data.save()
    # send_mail('Subscribed',
    #           f'Welcome to GAMERZONE\n Your email has been successfully registered for our newsletters\nWe will notify you about the latest products and updates\n\nTHANK YOU.. \n\nBest regards,\nGAMER ZONE',
    #           'settings.EMAIL_HOST_USER', [m], fail_silently=False)
    return render(request,'userhome.html')

def userrecentorders(request):
    if 'user' in request.session:
        user = register.objects.get(username=request.session['user'])
        order = Order.objects.filter(user=user,payment_status='PAID').order_by('-purchase_date')
        return render(request, 'myorderdetails.html',{'data':order})
    return redirect(login)

def adminrecentorders(request):
    if 'admin' in request.session:
        order = Order.objects.filter(payment_status='PAID').order_by('-purchase_date')
        print(order)
        return render(request,'admin_recent_orders.html',{'data': order})
    return redirect(login)


from django.utils.crypto import get_random_string
from django.core.mail import send_mail

def forgot_password(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        try:
            user = register.objects.get(email=email)
        except:
            messages.info(request, "Email id not registered")
            return redirect(forgot_password)
        # Generate and save a unique token
        token = get_random_string(length=4)
        PasswordReset.objects.create(user=user, token=token)

        # Send email with reset link
        reset_link = f'http://127.0.0.1:8000/reset/{token}'
        try:
            send_mail('Reset Your Password', f'Click the link to reset your password: {reset_link}',
                      'settings.EMAIL_HOST_USER', [email], fail_silently=False)
            # return render(request, 'emailsent.html')
        except:
            messages.info(request, "Network connection failed")
            return redirect(forgot_password)

    return render(request,'forgot_password.html')

def reset_password(request,token):
    # Verify token and reset the password
    print(token)
    password_reset = PasswordReset.objects.get(token=token)
    # usr = User.objects.get(id=password_reset.user_id)
    if request.method == 'POST':
        new_password = request.POST.get('newpassword')
        repeat_password = request.POST.get('cpassword')
        if repeat_password == new_password:
            password_reset.user.password=new_password
            password_reset.user.save()
            # password_reset.delete()
            return redirect(login)
    return render(request, 'reset_password.html', {'token': token})


def adminuser(request):
    if 'admin' in request.session:
        order = Order.objects.filter(payment_status='PAID',product_status='Order Placed')
        order1 = Order.objects.filter(payment_status='PAID',product_status='Preparing')
        order2 = Order.objects.filter(payment_status='PAID',product_status='Packing')
        order3 = Order.objects.filter(payment_status='PAID',product_status='Ready For Delivery')
        order4 = Order.objects.filter(payment_status='PAID',product_status='Out For Delivery')
        return render(request,'admin_user.html',{'data':order,'data1':order1,'data2':order2,'data3':order3,'data4':order4})
    return redirect(login)


def adminorderupdate(request,d):
    if 'admin' in request.session:
        ord = Order.objects.get(pk=d)
        e = ord.user.email
        f = ord.product_order
        g = ord.name
        print(g)
        if request.method == 'POST':
            a = request.POST.get('odsts')
            b = request.POST.get('inst')
            Order.objects.filter(pk=d).update(product_status=a, instruction=b)

            send_mail(f'{a}',
                      f'Hey {g},\n\nYour {f} is {a},\n{b} \n\n THANK YOU.',
                      'settings.EMAIL_HOST_USER', [e], fail_silently=False)
            return redirect(adminrecentorders)
        return render(request,'admin_order_update.html',{'data':ord})
    return redirect(login)


def lowstock(request):
      if 'admin' in request.session:

          pro = products.objects.all()
          l = []
          for i in pro:
              print(i.stock)

              if i.stock<=3:
                  l.append(i)
                  # d=products.objects.filter(productname=i.productname)
                  # print(d)
                  return redirect(lowstock)

      return render(request,'lowstock.html',{'e':l})

