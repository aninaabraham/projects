from django import forms
from .models import *

class model_form1(forms.ModelForm):
    class Meta:
        model=products
        fields='__all__'


class model_form(forms.ModelForm):
    class Meta:
        model=register
        fields='__all__'